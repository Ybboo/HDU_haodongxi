##............................................##
##在透视投影下，六面体的缩放、对称、旋转、错切变换     ##
##............................................##

from OpenGL.GL import *
from OpenGL.GLUT import *
from OpenGL.GLU import *

# 六面体的顶点坐标，边长为2的正方体
vertices = (
    (2, 0, 0),
    (2, 2, 0),
    (0, 2, 0),
    (0, 0, 0),
    (2, 0, 2),
    (2, 2, 2),
    (0, 0, 2),
    (0, 2, 2)
)

# 六面体的面
surfaces = (
    (0, 1, 2, 3),
    (3, 2, 7, 6),
    (6, 7, 5, 4),
    (4, 5, 1, 0),
    (1, 5, 7, 2),
    (4, 0, 3, 6)
)

# 颜色，每个面一个颜色
colors = (
    (1, 0, 0),  # 红色
    (0, 1, 0),  # 绿色
    (0, 0, 1),  # 蓝色
    (1, 1, 0),  # 黄色
    (1, 0, 1),  # 紫色
    (0, 1, 1)   # 青色
)

# 对称变换的标志
symmetric = False

# 错切变换的标志
shear = False

# 缩放变换的标志
scaling = False

# 旋转角度
rotation_angle = 0


def draw_cube():
    for i, surface in enumerate(surfaces):
        glColor3fv(colors[i])  # 每个面一个颜色
        glBegin(GL_QUADS)
        for vertex in surface:
            glVertex3fv(vertices[vertex])
        glEnd()


def draw_axes():
    glBegin(GL_LINES)
    glColor3f(1, 0, 0)  # X 轴：红色
    glVertex3f(-5, 0, 0)
    glVertex3f(5, 0, 0)
    glColor3f(0, 1, 0)  # Y 轴：绿色
    glVertex3f(0, -5, 0)
    glVertex3f(0, 5, 0)
    glColor3f(0, 0, 1)  # Z 轴：蓝色
    glVertex3f(0, 0, -5)
    glVertex3f(0, 0, 5)
    glEnd()


def display():
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    glLoadIdentity()
    gluPerspective(45, 1, 0.1, 50)#设置透视投影矩阵
    gluLookAt(10, 10, 10, 0, 0, 0, 0, 1, 0)#设置观察者的位置和方向

    # 对称变换，以z轴为对称轴
    if symmetric:
        glScalef(1, 1, -1)

    # 旋转变换，绕z轴旋转
    glRotatef(rotation_angle, 0, 0, 1)

    # 错切变换
    if shear:
        glTranslatef(0, 0, 1)  # 沿z轴错切

    # 缩放变换
    if scaling:
        glScalef(1.1, 1.1, 1.1)

    draw_axes()
    draw_cube()

    glutSwapBuffers()


def init():
    glClearColor(0, 0, 0, 1)
    glEnable(GL_DEPTH_TEST)


def keyboard(key, x, y):
    global symmetric, shear, scaling, rotation_angle
    if key == b's':
        symmetric = not symmetric
    elif key == b'e':
        shear = not shear
    elif key == b'w':
        scaling = not scaling
    elif key == b'r':
        rotation_angle += 10
        if rotation_angle >= 360:
            rotation_angle -= 360
    elif key == b'q':
        exit(0)
    glutPostRedisplay()


def main():
    glutInit()
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH)
    glutInitWindowSize(500, 500)
    glutCreateWindow(b"Transformations in Perspective Projection")
    init()
    glutDisplayFunc(display)
    glutKeyboardFunc(keyboard)
    glutMainLoop()


if __name__ == "__main__":
    main()
