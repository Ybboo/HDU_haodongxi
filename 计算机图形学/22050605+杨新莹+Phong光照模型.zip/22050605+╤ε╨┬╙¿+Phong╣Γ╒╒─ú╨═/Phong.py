import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QOpenGLWidget, QSlider, QLabel, QVBoxLayout, QHBoxLayout, QWidget
from PyQt5.QtCore import Qt
from OpenGL.GL import *
from OpenGL.GLU import *

# 旋转角度
angle_x = 0
angle_y = 0
mouse_last_x = 0
mouse_last_y = 0
mouse_left_down = False

# 光源位置和颜色
light_positions = [[0, 0, 4], [3, 3, 0]]
light_colors = [[1, 0, 0], [0, 0, 1]]


class OpenGLWidget(QOpenGLWidget):
    def initializeGL(self):
        glClearColor(0, 0, 0, 1)
        glEnable(GL_DEPTH_TEST)
        glEnable(GL_LIGHTING)
        glEnable(GL_LIGHT0)
        glEnable(GL_LIGHT1)
        self.init_lighting()

    def resizeGL(self, w, h):
        glViewport(0, 0, w, h)
        glMatrixMode(GL_PROJECTION)
        glLoadIdentity()
        gluPerspective(45, w / h, 0.1, 50)
        glMatrixMode(GL_MODELVIEW)

    def paintGL(self):
        global angle_x, angle_y
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        glLoadIdentity()
        gluLookAt(10, 10, 10, 0, 0, 0, 0, 1, 0)

        glPushMatrix()
        glRotatef(angle_x, 1, 0, 0)  # 绕X轴旋转
        glRotatef(angle_y, 0, 1, 0)  # 绕Y轴旋转
        self.update_lighting()
        self.draw_sphere()  # 绘制球体
        self.draw_light_sources()
        glPopMatrix()

        self.draw_axes()

    def init_lighting(self):  # 环境光
        glLightfv(GL_LIGHT0, GL_AMBIENT, [0.1, 0.1, 0.1, 1])
        glLightfv(GL_LIGHT1, GL_AMBIENT, [0.1, 0.1, 0.1, 1])
        # 设置光衰减（可选）
        glLightf(GL_LIGHT0, GL_CONSTANT_ATTENUATION, 1.0)
        glLightf(GL_LIGHT0, GL_LINEAR_ATTENUATION, 0.1)
        glLightf(GL_LIGHT0, GL_QUADRATIC_ATTENUATION, 0.01)
        glLightf(GL_LIGHT1, GL_CONSTANT_ATTENUATION, 1.0)
        glLightf(GL_LIGHT1, GL_LINEAR_ATTENUATION, 0.1)
        glLightf(GL_LIGHT1, GL_QUADRATIC_ATTENUATION, 0.01)

    def update_lighting(self):
        global light_positions, light_colors
        glLightfv(GL_LIGHT0, GL_POSITION, light_positions[0] + [1])
        glLightfv(GL_LIGHT0, GL_DIFFUSE, light_colors[0] + [1])  # 漫反射
        glLightfv(GL_LIGHT0, GL_SPECULAR, light_colors[0] + [1])  # 高光反射

        glLightfv(GL_LIGHT1, GL_POSITION, light_positions[1] + [1])
        glLightfv(GL_LIGHT1, GL_DIFFUSE, light_colors[1] + [1])
        glLightfv(GL_LIGHT1, GL_SPECULAR, light_colors[1] + [1])

    def draw_sphere(self):
        # 球体细分数（越高越精细）
        slices = 40
        stacks = 40
        # 球体半径
        radius = 1.5

        glPushMatrix()
        # 使用GLU库的球体绘制函数
        quadric = gluNewQuadric()
        glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, (1, 1, 1, 1))  # 设置球体颜色（白色）
        gluSphere(quadric, radius, slices, stacks)
        gluDeleteQuadric(quadric)
        glPopMatrix()

    def draw_axes(self):
        glDisable(GL_LIGHTING)  # 禁用光照
        glBegin(GL_LINES)
        glColor3f(1, 0, 0)  # X 轴：红色
        glVertex3f(-5, 0, 0)
        glVertex3f(5, 0, 0)
        glColor3f(0, 1, 0)  # Y 轴：绿色
        glVertex3f(0, -5, 0)
        glVertex3f(0, 5, 0)
        glColor3f(0, 0, 1)  # Z 轴：蓝色
        glVertex3f(0, 0, -5)
        glVertex3f(0, 0, 5)
        glEnd()
        glEnable(GL_LIGHTING)  # 重新启用光照

    def draw_light_sources(self):
        global light_positions, light_colors
        glDisable(GL_LIGHTING)  # 禁用光照
        for i in range(2):
            glColor3fv(light_colors[i])
            glPushMatrix()
            glTranslatef(*light_positions[i])
            gluSphere(gluNewQuadric(), 0.2, 20, 20)
            glPopMatrix()
        glEnable(GL_LIGHTING)  # 重新启用光照


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Phong Lighting Model")
        self.setGeometry(100, 100, 1200, 1000)

        self.opengl_widget = OpenGLWidget(self)

        # 创建光源位置控件
        self.light_position_labels = [QLabel(f"Light 0 Position: {light_positions[0]}", self),
                                      QLabel(f"Light 1 Position: {light_positions[1]}", self)]
        self.position_slider_labels = [["X red (Light 0)", "Y green (Light 0)", "Z blue (Light 0)"],
                                       ["X red (Light 1)", "Y green (Light 1)", "Z blue (Light 1)"]]
        self.position_sliders = [[QSlider(Qt.Horizontal, self) for _ in range(3)],
                                 [QSlider(Qt.Horizontal, self) for _ in range(3)]]
        self.position_layouts = [QVBoxLayout(), QVBoxLayout()]

        for i in range(2):
            self.position_layouts[i].addWidget(self.light_position_labels[i])
            for j in range(3):
                slider_label = QLabel(self.position_slider_labels[i][j], self)
                self.position_layouts[i].addWidget(slider_label)
                self.position_sliders[i][j].setRange(-10, 10)
                self.position_sliders[i][j].setValue(light_positions[i][j])
                self.position_sliders[i][j].valueChanged.connect(self.update_light_position)
                self.position_layouts[i].addWidget(self.position_sliders[i][j])

        # 创建光源颜色控件
        self.light_color_labels = [QLabel(f"Light 0 Color: {light_colors[0]}", self),
                                   QLabel(f"Light 1 Color: {light_colors[1]}", self)]
        self.color_slider_labels = [["Red (Light 0)", "Green (Light 0)", "Blue (Light 0)"],
                                    ["Red (Light 1)", "Green (Light 1)", "Blue (Light 1)"]]
        self.color_sliders = [[QSlider(Qt.Horizontal, self) for _ in range(3)],
                              [QSlider(Qt.Horizontal, self) for _ in range(3)]]
        self.color_layouts = [QVBoxLayout(), QVBoxLayout()]

        for i in range(2):
            self.color_layouts[i].addWidget(self.light_color_labels[i])
            for j in range(3):
                slider_label = QLabel(self.color_slider_labels[i][j], self)
                self.color_layouts[i].addWidget(slider_label)
                self.color_sliders[i][j].setRange(0, 100)
                self.color_sliders[i][j].setValue(int(light_colors[i][j] * 100))
                self.color_sliders[i][j].valueChanged.connect(self.update_light_color)
                self.color_layouts[i].addWidget(self.color_sliders[i][j])

        # 布局设置
        self.control_layout = QVBoxLayout()
        self.control_layout.addLayout(self.position_layouts[0])
        self.control_layout.addLayout(self.color_layouts[0])
        self.control_layout.addLayout(self.position_layouts[1])
        self.control_layout.addLayout(self.color_layouts[1])
        self.control_layout.addStretch(1)

        self.control_widget = QWidget(self)
        self.control_widget.setLayout(self.control_layout)

        self.main_layout = QHBoxLayout()
        self.main_layout.addWidget(self.opengl_widget, 1)
        self.main_layout.addWidget(self.control_widget)

        self.main_widget = QWidget()
        self.main_widget.setLayout(self.main_layout)
        self.setCentralWidget(self.main_widget)

    def mousePressEvent(self, event):
        global mouse_left_down, mouse_last_x, mouse_last_y
        if event.button() == Qt.LeftButton:
            mouse_left_down = True
            mouse_last_x = event.x()
            mouse_last_y = event.y()

    def mouseReleaseEvent(self, event):
        global mouse_left_down
        if event.button() == Qt.LeftButton:
            mouse_left_down = False

    def mouseMoveEvent(self, event):
        global angle_x, angle_y, mouse_last_x, mouse_last_y
        if mouse_left_down:
            dx = event.x() - mouse_last_x
            dy = event.y() - mouse_last_y
            angle_x += dy * 0.5
            angle_y += dx * 0.5
            mouse_last_x = event.x()
            mouse_last_y = event.y()
            self.opengl_widget.update()

    def update_light_position(self):
        global light_positions
        for i in range(2):
            light_positions[i] = [slider.value() for slider in self.position_sliders[i]]
            self.light_position_labels[i].setText(f"Light {i} Position: {light_positions[i]}")
        self.opengl_widget.update()

    def update_light_color(self):
        global light_colors
        for i in range(2):
            light_colors[i] = [slider.value() / 100 for slider in self.color_sliders[i]]
            self.light_color_labels[i].setText(f"Light {i} Color: {light_colors[i]}")
        self.opengl_widget.update()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())
