#代码实现说明：
#通过鼠标点击窗体来添加控制点，当按下回车键，停止添加控制点
#停止添加控制点后，可以通过鼠标来拖动控制点，修改曲线形状
from OpenGL.GL import *
from OpenGL.GLUT import *
import numpy as np

# 控制点
control_points = []

# 是否允许添加新的控制点
allow_adding_points = True

# 是否处于控制点移动模式
is_move_mode = False

# 选中的控制点索引
selected_point_index = -1


# 计算Bezier曲线上的点
def bezier_curve(control_points, t):
    n = len(control_points) - 1
    result = [0, 0]
    for i in range(n + 1):
        result[0] += control_points[i][0] * binomial_coefficient(n, i) * ((1 - t) ** (n - i)) * (t ** i)
        result[1] += control_points[i][1] * binomial_coefficient(n, i) * ((1 - t) ** (n - i)) * (t ** i)
    return result


# 计算二项式系数
def binomial_coefficient(n, k):
    result = 1
    for i in range(1, k + 1):
        result *= (n - i + 1) / i
    return result


# 鼠标点击事件处理函数
# 鼠标点击事件处理函数
def mouse(button, state, x, y):
    global allow_adding_points, selected_point_index, is_move_mode
    if allow_adding_points and button == GLUT_LEFT_BUTTON and state == GLUT_DOWN:
        # 将鼠标点击位置的窗口坐标转换为归一化坐标
        x_normalized = 2 * (x / glutGet(GLUT_WINDOW_WIDTH)) - 1
        y_normalized = 1 - 2 * (y / glutGet(GLUT_WINDOW_HEIGHT))

        # 添加新的控制点
        control_points.append((x_normalized, y_normalized))

        # 通知OpenGL窗口需要重新绘制
        glutPostRedisplay()
    elif button == GLUT_LEFT_BUTTON and state == GLUT_DOWN:
        # 寻找离鼠标点击位置最近的控制点
        min_distance = float('inf')
        for i, point in enumerate(control_points):
            distance = np.sqrt((2 * x / glutGet(GLUT_WINDOW_WIDTH) - 1 - point[0]) ** 2 + (
                        1 - 2 * y / glutGet(GLUT_WINDOW_HEIGHT) - point[1]) ** 2)
            if distance < min_distance:
                min_distance = distance
                selected_point_index = i
        if min_distance < 0.05:  # 如果鼠标点击到了控制点附近，则进入控制点移动模式
            is_move_mode = True
    elif button == GLUT_LEFT_BUTTON and state == GLUT_UP:
        is_move_mode = False
        selected_point_index = -1


# 鼠标移动事件处理函数
def motion(x, y):
    global selected_point_index, is_move_mode
    if is_move_mode:
        # 将鼠标位置的窗口坐标转换为归一化坐标
        x_normalized = 2 * (x / glutGet(GLUT_WINDOW_WIDTH)) - 1
        y_normalized = 1 - 2 * (y / glutGet(GLUT_WINDOW_HEIGHT))

        # 更新选中控制点的坐标
        control_points[selected_point_index] = (x_normalized, y_normalized)

        # 通知OpenGL窗口需要重新绘制
        glutPostRedisplay()


# 键盘事件处理函数
def keyboard(key, x, y):
    global allow_adding_points
    if key == b'\r':  # 按下回车键
        allow_adding_points = False
    elif key == b'\x1b':  # 按下ESC键
        allow_adding_points = True


# 绘制函数
def draw():
    glClear(GL_COLOR_BUFFER_BIT)
    glColor3f(1.0, 1.0, 1.0)

    # 绘制Bezier曲线
    glBegin(GL_LINE_STRIP)
    for t in np.arange(0, 1.01, 0.01):
        point = bezier_curve(control_points, t)
        glVertex2fv(point)
    glEnd()

    # 绘制控制点
    glColor3f(1.0, 0.0, 0.0)
    glPointSize(5.0)
    glBegin(GL_POINTS)
    for point in control_points:
        glVertex2fv(point)
    glEnd()

    # 连接相邻的控制点
    glColor3f(0.0, 1.0, 0.0)
    glBegin(GL_LINES)
    for i in range(len(control_points) - 1):
        glVertex2fv(control_points[i])
        glVertex2fv(control_points[i + 1])
    glEnd()

    glFlush()


# 主函数
def main():
    glutInit()
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB)
    glutInitWindowSize(400, 400)
    glutCreateWindow(b"Bezier Curve")

    glClearColor(0.0, 0.0, 0.0, 0.0)  # 将窗体的背景色设置为黑色

    glMatrixMode(GL_PROJECTION)
    glLoadIdentity()
    glOrtho(-1.0, 1.0, -1.0, 1.0, -1.0, 1.0)
    glMatrixMode(GL_MODELVIEW)

    glutMouseFunc(mouse)
    glutMotionFunc(motion)
    glutDisplayFunc(draw)
    glutKeyboardFunc(keyboard)

    glutMainLoop()


if __name__ == "__main__":
    main()
